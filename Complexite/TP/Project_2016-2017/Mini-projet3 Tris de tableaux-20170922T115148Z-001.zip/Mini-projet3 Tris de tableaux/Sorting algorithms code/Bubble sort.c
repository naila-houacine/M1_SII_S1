/* BENDJOUDI & ROUGAB M1SII */
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#define Length 10000

typedef long *array;
array A;

void bubbleSort(array a){
    int i,j,tmp;
    int flag;        //taking a flag variable
    for(i=0; i<Length-1; i++){
        flag=0;
        for(j=0; j<Length-i-1; j++){
           if( a[j] > a[j+1]){
                tmp = a[j];
                a[j] = a[j+1];
                a[j+1] = tmp;
                flag = 1;         //setting flag as 1, if swapping occurs
           }
        }
        if(!flag){             //breaking out of for loop if no swapping takes place
           break;
        }
     }
}

int main()
{
    clock_t start, end;
    double time;
    long i;

    /*Allocation*/
    A =(long *)malloc(Length*sizeof(long));

    /*Initialization of the array */
    for(i=0;i<Length;i++){
        A[i]=Length-i;
    }

    /*Display the unsorted array*/
    for(i=0;i<Length;i++){
        printf("%d ",A[i]);
    }

    start=clock();

    bubbleSort(A); //call of the sorting function

    end=clock();
    time=(float)(end-start)/CLOCKS_PER_SEC; //calculation of runtime

    /*Display the sorted array */
    printf("\n\n");
    for(i=0;i<Length;i++){
        printf("%d ",A[i]);
    }

    printf("\n\nRuntime =  %f\n", time); //Display runtime

}
