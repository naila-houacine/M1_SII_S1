/* BENDJOUDI & ROUGAB M1SII */
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#define Length 10000

typedef long *array;
array A;
void insertionSort(array a){

    long i, j, tmp;
    for(i=1;i<Length;i++){
        j=i;
        tmp=a[i];
        while(j>0 && tmp<a[j-1]){
            a[j]=a[j-1];
            j--;
        }
        a[j]=tmp;
    }
}

int main()
{
    clock_t start, end;
    double time;
    long i;

    /*Allocation*/
    A =(long *)malloc(Length*sizeof(long));

    /*Initialization of the array */
    for(i=0;i<Length;i++){
        A[i]=Length-i;
    }

    /*Display the unsorted array*/
    for(i=0;i<Length;i++){
        printf("%d ",A[i]);
    }

    start=clock();

    insertionSort(A); //call of the sorting function

    end=clock();
    time=(float)(end-start)/CLOCKS_PER_SEC; //calculation of runtime

    /*Display the sorted array */
    printf("\n\n");
    for(i=0;i<Length;i++){
        printf("%d ",A[i]);
    }

    printf("\n\nRuntime =  %f\n", time); //Display runtime

}
