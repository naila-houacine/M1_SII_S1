/* BENDJOUDI & ROUGAB M1SII */
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#define Length 10000

typedef long *tab_entiers;
tab_entiers T;

void selectionSort(tab_entiers t){
    long i,j,min,imin;
    for(i=0;i<Length-1;i++){
        imin=i;
        for(j=i+1;j<Length;j++){
           if(t[imin]>t[j]){
              min=t[j];
              imin= j;
           }
        }
        if(imin != i){
           t[imin]=t[i];
           t[i]=min;
        }
    }
}

int main()
{
    clock_t start, end;
    double time;
    long i;

    /*Allocation*/
    T =(long *)malloc(Length*sizeof(long));

    /*Initialization of the array */
    for(i=0;i<Length;i++){
        T[i]=Length-i;
    }

    /*Display the unsorted array*/
    for(i=0;i<Length;i++){
        printf("%d ",T[i]);
    }

    start=clock();

    selectionSort(T); //call of the sorting function

    end=clock();
    time=(float)(end-start)/CLOCKS_PER_SEC; //calculation of runtime

    /*Display the sorted array */
    printf("\n\n");
    for(i=0;i<Length;i++){
        printf("%d ",T[i]);
    }

    printf("\n\nRuntime =  %f\n", time); //Display runtime

}
