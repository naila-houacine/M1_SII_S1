/* BENDJOUDI & ROUGAB M1SII */
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#define Length 10000

typedef long *array;
array A;
array Tmp;

/*********** Procedure Merge ************/
void merge(array a, long first1,long last1,long first2,long last2){
   long i = first1;
   long j = first2;
   long k = 0;
   while (i<=last1 && j<=last2){
   	if (a[i] < a[j]){
	   Tmp[k] = a[i];
	   i++;
	   k++;
	   }
	else{
	   Tmp[k] = a[j];
	   k++;
	   j++;}
    }
   while (i<=last1) {Tmp[k] = a[i]; k++;i++;}
   while (j<=last2) {Tmp[k] = a[j]; k++; j++;}

   for (j=0; j<k; j++)
	a[first1+j] = Tmp[j];
}
/*********** Procedure merge sort ************/
void mergeSort(array a, long first, long last)
{
   long middle,i,j;
   if (first>=last) return;
   middle = (first+last)/2;
   mergeSort(a,first,middle);
   mergeSort(a,middle+1,last);
   merge(a,first,middle,middle+1,last);
}

int main()
{
    clock_t start, end;
    double time;
    long i;

    /*Allocation*/
    A =(long *)malloc(Length*sizeof(long));
    Tmp =(long *)malloc(Length*sizeof(long));

    /*Initialization of the array  */
    for(i=0;i<Length;i++){
        A[i]=Length-i;
    }

    /*Display the unsorted array*/
    for(i=0;i<Length;i++){
        printf("%d ",A[i]);
    }

    start=clock();

    mergeSort(A,0,Length); //call of the sorting function

    end=clock();
    time=(float)(end-start)/CLOCKS_PER_SEC; //calculation of runtime

    /*Display the sorted array */
    printf("\n\n");
    for(i=0;i<Length;i++){
        printf("%d ",A[i]);
    }

    printf("\n\nRuntime =  %f\n", time); //Display runtime

}
