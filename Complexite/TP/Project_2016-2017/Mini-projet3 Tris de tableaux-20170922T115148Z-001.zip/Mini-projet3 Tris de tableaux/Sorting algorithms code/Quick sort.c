/* BENDJOUDI & ROUGAB M1SII */
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#define Length 100000

typedef long *array;
array A;

/*********** Procedure quick sort ************/
void quickSort(array a, long first, long last)
{
  if(first < last)
  {
    long splitpoint;
    splitpoint = partition(a, first, last);
    quickSort(a, first, splitpoint);
    quickSort(a, splitpoint+1, last);
  }
}

/*********** Procedure partition ************/

int partition(array a, long first, long last)
{
  long i, j, pivot, tmp;
  i = first;
  j = last;
  pivot = a[(first+last)/2];
  while(1)
  {
   while(a[i] < pivot && a[i] != pivot)
   { i++;}
   while(a[j] > pivot && a[j] != pivot)
   {j--;}
   if(i < j)
   {
    tmp = a[i];
    a[i] = a[j];
    a[j] = tmp;
   }
   else
   {
    return j;
   }
  }
}

int main()
{
    clock_t start, end;
    double time;
    long i;

    /*Allocation*/
    A =(long *)malloc(Length*sizeof(long));

    /*Initialization of the array  */
    for(i=0;i<Length;i++){
        A[i]=Length-i;
    }

    /*Display the unsorted array*/
    for(i=0;i<Length;i++){
        printf("%d ",A[i]);
    }

    start=clock();

    quickSort(A,0,Length); //call of the sorting function

    end=clock();
    time=(float)(end-start)/CLOCKS_PER_SEC; //calculation of runtime

    /*Display the sorted array */
    printf("\n\n");
    for(i=0;i<Length;i++){
        printf("%d ",A[i]);
    }

    printf("\n\nRuntime =  %f\n", time); //Display runtime

}
