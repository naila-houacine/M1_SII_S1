#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <time.h>

double A1(long long nombre)
{

    int cpt=0; long long x=2;
    while((x<nombre)&&(cpt==0))
    {
        if(nombre%x==0)
            cpt++;
        else
            x++;
    }
    if(cpt>=1)
        printf("Nombre non premier\n");
    else
        printf("Nombre premier\n");


}

double A2(long long nombre)
{

    int cpt=0; long long x=2;
    while((x<=nombre/2)&&(cpt==0))
    {
        if(nombre%x==0)
            cpt++;
        else
            x++;
    }
    if(cpt>=1)
        printf("Nombre non premier\n");
    else
        printf("Nombre premier\n");

}

double A3(long long nombre)
{
    int cpt; long long x;
    if((nombre!=2)&&(nombre%2)==0)
        cpt++;
    else
    {
        cpt=0; x=3;
        while((x<=nombre-2)&&(cpt==0))
        {
            if(nombre%x==0)
                cpt++;
            else
                x+=2;
        }
    }
    if(cpt>=1)
         printf("Nombre non premier\n");
    else
         printf("Nombre premier\n");
}

double Premier4(long long nombre)
{

    int cpt; long long x;
    if((nombre!=2)&&(nombre%2)==0)
        cpt++;
    else
    {
        cpt=0; x=3;
        while((x<=nombre/2)&&(cpt==0))
        {
            if(nombre%x==0)
                cpt++;
            else
                x+=2;
        }
    }
    if(cpt>=1)
         printf("Nombre non premier\n");
    else
         printf("Nombre premier\n");
}

double A5(long long nombre)
{

    int cpt=0; long long x=2;
    while((x<(long)sqrt(nombre)+1)&&(cpt==0))
    {
        if(nombre%x==0)
            cpt++;
        else
            x++;
    }
    if(cpt>=1)
        printf("Nombre non premier\n");
    else
        printf("Nombre premier\n");

}

double A6(long long nombre)
{

    int cpt; long long x;
    if((nombre!=2)&&(nombre%2)==0)
        cpt++;
    else
    {
        cpt=0; x=3;
        while((x<=(long)sqrt(nombre))&&(cpt==0))
        {
            if(nombre%x==0)
                cpt++;
            else
                x+=2;
        }
    }
    if(cpt>=1)
         printf("Nombre non premier\n");
    else
         printf("Nombre premier\n");

}


int main(){
//Code concernant le test des algorithmes sur 20 nombres

long long tableau[20]=
{
14690633,
18692719,
21692309,
25692103,
29691293,
33691429,
36692129,
39692371,
42694213,
46692983,
50692991,
53694293,
58692419,
60692449,
62692493,
65692927,
71693779,
76692439,
85692469,
90692893
};
    clock_t debut,fin;
    double temps_exe=0;
    FILE* fichier = NULL;
    fichier = fopen("temps.txt", "w");
    int j;
	for(j=0;j<20;j++)
    {
        debut=clock();
        temps_exe=A6(tableau[j]);
        fin=clock();
        temps_exe=(double)(fin-debut)/CLOCKS_PER_SEC;
        fprintf(fichier,"%f\n",temps_exe);
    }

    fclose(fichier);

//Code concernant le calcul du temps moyen
	/*
			long long nombre=100123456789;
			double temps_exec;
			int i;
			double moy_temps;
			moy_temps=0;
			for(i=0;i<30;i++)
			{
				temps_exec=A4(nombre); // on change d'algorithme à chaque fois, pour les tester tous
				moy_temps+=temps_exec;
			}
			moy_temps/=30;
			printf("%f\n",moy_temps); 
	*/
}
}
